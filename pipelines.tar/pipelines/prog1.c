#include <stdio.h>

int main(){
  printf("Hello World!");
  if (1 < 2) {
    return 1;
  } else {
    return 0;
  }
}
