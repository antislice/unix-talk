#include <stdio.h>
#define HELLO "Hello World!"

int main(){
  printf(HELLO);
  return 0;
}
